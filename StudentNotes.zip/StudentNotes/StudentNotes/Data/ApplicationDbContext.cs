﻿using Microsoft.EntityFrameworkCore;
using StudentNotes.Models.Entities;

namespace StudentNotes.Data
{
    public class ApplicationDbContext : DbContext
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> Options) : base(Options)
        {

        }

        public DbSet<NotesDetails> NotesDetails { get; set; }
    }
}
