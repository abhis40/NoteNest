﻿using System.ComponentModel.DataAnnotations;

namespace StudentNotes.Models
{
    public class AddNotes
    {
        [Required]
        public string? Name { get; set; }
        [Required]
        public string? Subject { get; set; }
        [Required]
        public string? Description { get; set; }
        [Required]
        public string? DriveLink { get; set; }
    }
}
