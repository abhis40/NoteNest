﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using StudentNotes.Data;
using StudentNotes.Models;
using StudentNotes.Models.Entities;

namespace StudentNotes.Controllers
{
    public class NotesController : Controller
    {
        private readonly ApplicationDbContext dbContext;

        public NotesController(ApplicationDbContext dbContext)
        {
            this.dbContext = dbContext;
        }

        [HttpGet]
        public IActionResult Add()
        {
            return View();
        }
        [HttpPost]

        public async Task<IActionResult> Add(AddNotes viewModel)
        {
            var note = new NotesDetails
            {
                Name = viewModel.Name,
                Subject = viewModel.Subject,
                Description = viewModel.Description,
                DriveLink = viewModel.DriveLink


            };
            await dbContext.NotesDetails.AddAsync(note);
            await dbContext.SaveChangesAsync();
            return View();
            
        }
        [HttpGet]
        public async Task<IActionResult> List()
        {
            var myNotes = await dbContext.NotesDetails.ToListAsync();
            return View(myNotes);
        }
    }
}
